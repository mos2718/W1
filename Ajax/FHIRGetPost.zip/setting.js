﻿var FHIRrootURL = "http://hapi.fhir.org/baseDstu3";
//5. FHIR TW with HTTPS  https://hapi.fhir.tw/
// H707 實驗室  http://203.64.84.182:8036/
var rootOrgID = "1856069";
//http://hapi.fhir.org/baseDstu3/Patient?organization=1856069