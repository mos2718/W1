﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Post : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

        try
        {
            // Get Method
            if (Request.RequestType != "POST")
            {
                reply(Error_("方法錯誤，請使用POST，並遵循上傳規則"));
                return;
            }

            // Get collection
            NameValueCollection qstr = Request.QueryString;
            if (qstr.Count != 1)
            {
                reply(Error_("方法錯誤，請使用POST，並遵循上傳規則"));
                return;
            }
            if (qstr.GetKey(0) != "id")
            {
                reply(Error_("方法錯誤，查無id，並遵循上傳規則"));
                return;
            }
            FileInfo f = new FileInfo("d:\\httptest\\" + qstr.Get(0) + ".txt");
           // FileInfo f = new FileInfo("C:\\inetpub\\wwwroot\\httptest\\" + qstr.Get(0) + ".txt");
            StreamWriter sw;
            if (f.Exists)
            {
                sw = f.AppendText();
            }
            else
            {
                sw = f.CreateText();
            }

            //POST
            StreamReader reader = new StreamReader(Request.InputStream);
            string xmlData;
            xmlData = reader.ReadToEnd();

            sw.WriteLine(xmlData);

            sw.Flush();
            sw.Close();

            reply(success());

        }
        catch (Exception ex)
        {
            reply(Error_(ex.Message + "請重新傳送"));
        }
    }
    private void reply(string xml)
    {
        Response.Clear();
        Response.ContentType = "text/xml";
        //Response.ContentEncoding = System.Text.Encoding.GetEncoding("utf-8");
        Response.Write(xml);
    }
    private string Error_(string err)
    {
        string xml = "";
        xml += "<?xml version=\"1.0\" encoding=\"utf-8\" ?>\r\n";
        xml += "<OperationOutcome xmlns=\"http://hl7.org/fhir\">\r\n";
        xml += "\t<issue>\r\n";
        xml += "\t\t<severity value=\"error\"/>\r\n";
        xml += "\t\t<details>\r\n";
        xml += "\t\t\t<text value=\"" + err + "\"/>\r\n";
        xml += "\t\t</details>\r\n";
        xml += "\t</issue>\r\n";
        xml += "</OperationOutcome>\r\n";
        xml = "資訊有誤";
        return xml;
    }
    private string success()
    {
        string xml = "";
        xml += "<?xml version=\"1.0\" encoding=\"utf-8\" ?>\r\n";
        xml += "<OperationOutcome xmlns=\"http://hl7.org/fhir\">\r\n";
        xml += "\t<issue>\r\n";
        xml += "\t\t<severity value=\"information\"/>\r\n";
        xml += "\t\t<details>\r\n";
        xml += "\t\t\t<text value=\"success\"/>\r\n";
        xml += "\t\t</details>\r\n";
        xml += "\t</issue>\r\n";
        xml += "</OperationOutcome>\r\n";
        xml = "報名成功";
        return xml;
    }
}