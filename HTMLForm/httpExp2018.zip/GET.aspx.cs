﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class GET : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

        // Get Method
        if (Request.RequestType != "GET")
        {
            reply(Error_("wrong method"));
            return;
        }
        //POST
        string xmlData;
        StreamReader reader = new StreamReader(Request.InputStream);
        //string xmlData = ;
        xmlData = reader.ReadToEnd();
        if (xmlData != "")
        {
            reply(Error_("wrong method"));
            return;
        }

        // Get collection
        NameValueCollection qstr = Request.QueryString;
        if (qstr.Count != 1)
        {
            reply(Error_("方法錯誤，請使用POST，並遵循上傳規則"));
            return;
        }
        if (qstr.GetKey(0) != "id")
        {
            reply(Error_("方法錯誤，查無id，並遵循上傳規則"));
            return;
        }
        string xml = "",a="";
        int k = 0;
        xml += "<?xml version=\"1.0\" encoding=\"utf-8\" ?>\r\n";
        xml += "<Bundle xmlns=\"http://hl7.org/fhir\">\r\n";

        FileInfo f = new FileInfo("D:\\httptest\\" + qstr.Get(0) + ".txt");
        StreamReader sr = f.OpenText();
        while (sr.Peek() >= 0)
        {
            k++;
            a += "\t<entry>\r\n";
            a += sr.ReadLine();
            a += "\t</entry>\r\n";
        }
        sr.Close();
        xml += "\t<total value=\"" + k.ToString() + "\"/>\r\n";
        xml += a;
        xml += "</Bundle>";
        reply(xml);

    }
    private void reply(string xml)
    {
        Response.Clear();
        Response.ContentType = "text/xml";
        //Response.ContentEncoding = System.Text.Encoding.GetEncoding("utf-8");
        Response.Write(xml);
    }
    private string Error_(string err)
    {
        string xml = "";
        xml += "<?xml version=\"1.0\" encoding=\"utf-8\" ?>\r\n";
        xml += "<Bundle xmlns=\"http://hl7.org/fhir\">\r\n";
        xml += "\t<total value=\"0\"/>\r\n";
        xml += "\t<entry>\r\n";
        xml += "\t\t<response>\r\n";
        xml += "\t\t\t<status value=\"" + err + "\" />\r\n";
        xml += "\t\t</response>\r\n";
        xml += "\t</entry>\r\n";
        xml += "</Bundle>";
        return xml;
    }
}